import { query } from './index.js';

export async function initSchema() {
  await query(`
    CREATE TABLE IF NOT EXISTS users (
      id SERIAL PRIMARY KEY,
      discord_id TEXT UNIQUE NOT NULL,
      username TEXT,
      key_id INTEGER,
      is_reseller BOOLEAN DEFAULT FALSE,
      reseller_balance INTEGER DEFAULT 0,
      created_at TIMESTAMPTZ DEFAULT NOW()
    )
  `);

  await query(`
    CREATE TABLE IF NOT EXISTS license_keys (
      id SERIAL PRIMARY KEY,
      key_value TEXT UNIQUE NOT NULL,
      type TEXT NOT NULL DEFAULT 'basic',
      duration_days INTEGER NOT NULL DEFAULT 30,
      is_active BOOLEAN DEFAULT TRUE,
      used_by TEXT,
      used_at TIMESTAMPTZ,
      expires_at TIMESTAMPTZ,
      created_by TEXT,
      created_at TIMESTAMPTZ DEFAULT NOW()
    )
  `);

  await query(`
    CREATE TABLE IF NOT EXISTS tokens (
      id SERIAL PRIMARY KEY,
      user_discord_id TEXT NOT NULL,
      token_value TEXT NOT NULL,
      token_name TEXT DEFAULT 'My Token',
      is_selected BOOLEAN DEFAULT FALSE,
      auto_reply_enabled BOOLEAN DEFAULT FALSE,
      bypass_enabled BOOLEAN DEFAULT FALSE,
      created_at TIMESTAMPTZ DEFAULT NOW()
    )
  `);

  await query(`
    CREATE TABLE IF NOT EXISTS ad_jobs (
      id SERIAL PRIMARY KEY,
      token_id INTEGER NOT NULL,
      user_discord_id TEXT NOT NULL,
      message TEXT NOT NULL,
      channel_ids JSONB DEFAULT '[]',
      delay_seconds INTEGER DEFAULT 60,
      images JSONB DEFAULT '[]',
      is_running BOOLEAN DEFAULT FALSE,
      last_cycle_at TIMESTAMPTZ,
      created_at TIMESTAMPTZ DEFAULT NOW()
    )
  `);

  await query(`
    CREATE INDEX IF NOT EXISTS idx_tokens_user ON tokens(user_discord_id)
  `);
  await query(`
    CREATE INDEX IF NOT EXISTS idx_ad_jobs_token ON ad_jobs(token_id)
  `);
  await query(`
    CREATE INDEX IF NOT EXISTS idx_ad_jobs_user ON ad_jobs(user_discord_id)
  `);
  await query(`
    CREATE INDEX IF NOT EXISTS idx_license_keys_value ON license_keys(key_value)
  `);

  console.log('✅ Database schema ready.');
}

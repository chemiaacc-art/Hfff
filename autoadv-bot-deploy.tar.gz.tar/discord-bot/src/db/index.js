import pg from 'pg';
const { Pool } = pg;

const noSsl = process.env.DATABASE_URL?.includes('localhost') || process.env.DATABASE_URL?.includes('railway.internal');

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: noSsl ? false : { rejectUnauthorized: false }
});

export async function query(text, params) {
  const client = await pool.connect();
  try {
    const res = await client.query(text, params);
    return res;
  } finally {
    client.release();
  }
}

export default pool;

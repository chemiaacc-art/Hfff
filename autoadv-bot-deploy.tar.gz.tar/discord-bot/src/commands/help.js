import { SlashCommandBuilder } from 'discord.js';

export const data = new SlashCommandBuilder()
  .setName('help')
  .setDescription('View all available commands');

export async function execute(interaction) {
  return interaction.reply({
    embeds: [{
      color: 0x5865F2,
      title: '📚 AUT0adv — Commands',
      fields: [
        {
          name: '🚀 Getting Started',
          value: '`/redeem_key` — activate with a license key\n`/setup` — quick-start guide\n`/help` — this menu'
        },
        {
          name: '🎛️ Dashboard (Main Panel)',
          value: '`/dashboard` — **all-in-one control panel**\n> ➕ Add Token · ▶ Start All · ⏹ Stop All · 🔄 Refresh\n> Select a token → New Ad Job · Edit · Start/Stop · Rename · Delete\n> Select a job → Edit · Start/Stop · Delete'
        },
        {
          name: '🔑 Token Management',
          value: '`/settoken` `/listtokens` `/selecttoken` `/removetoken`\n`/tokenstart` `/tokenstop` `/tokenstatus` `/tokenconfig`'
        },
        {
          name: '⚙️ Panels',
          value: '`/configpanel` — status panel with Start/Stop All buttons\n`/togglepanel <token_id>` — toggle Auto-Reply & Bypass'
        },
        {
          name: 'ℹ️ Info',
          value: '`/status` `/profile` `/stats` `/leaderboard` `/startall`'
        },
        {
          name: '💼 Reseller',
          value: '`/balance` `/reseller_gen` `/transfer_reseller`'
        },
        {
          name: '🛡️ Admin Only',
          value: '`/admin_genkey` `/admin_reseller` `/trial_drop`'
        }
      ],
      footer: { text: 'AUT0adv • Use /dashboard for everything in one place' }
    }],
    ephemeral: true
  });
}

import {
  SlashCommandBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  StringSelectMenuBuilder,
  EmbedBuilder,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle
} from 'discord.js';
import { requireKey } from '../utils/checkKey.js';
import { query } from '../db/index.js';
import { maskToken, formatExpiry, parseChannelIds } from '../utils/keys.js';
import { isJobRunning, startAdJob, stopAdJob } from '../utils/adRunner.js';

export const data = new SlashCommandBuilder()
  .setName('dashboard')
  .setDescription('All-in-one ad campaign control panel');

export async function execute(interaction) {
  await interaction.deferReply({ ephemeral: true });
  const user = await requireKey(interaction);
  if (!user) return;
  await sendDashboard(interaction, interaction.user.id, user);
}

// ─── MAIN DASHBOARD ──────────────────────────────────────────────────────────

async function buildDashboardEmbed(discordId, user) {
  const tokensRes = await query(
    `SELECT t.*,
      (SELECT COUNT(*) FROM ad_jobs aj WHERE aj.token_id = t.id AND aj.is_running = TRUE) as running_jobs,
      (SELECT COUNT(*) FROM ad_jobs aj WHERE aj.token_id = t.id) as total_jobs
     FROM tokens t WHERE t.user_discord_id = $1 ORDER BY t.id`,
    [discordId]
  );
  const tokens = tokensRes.rows;
  const totalRunning = tokens.reduce((a, t) => a + parseInt(t.running_jobs), 0);
  const totalJobs = tokens.reduce((a, t) => a + parseInt(t.total_jobs), 0);

  const embed = new EmbedBuilder()
    .setColor(totalRunning > 0 ? 0x57F287 : 0x5865F2)
    .setTitle('🎛️ AUT0adv Dashboard')
    .setDescription(
      tokens.length === 0
        ? '> No tokens yet. Click **➕ Add Token** to get started.'
        : '> Select a token from the dropdown to manage it, or use the buttons above.'
    )
    .addFields({
      name: '📊 Overview',
      value: [
        `**Tokens:** ${tokens.length}`,
        `**Total Jobs:** ${totalJobs}`,
        `**Running:** 🟢 ${totalRunning}`,
        `**License:** ${user.type || 'basic'} — ${formatExpiry(user.expires_at)}`
      ].join('  ·  '),
      inline: false
    });

  if (tokens.length > 0) {
    const tokenList = tokens.map(t => {
      const running = parseInt(t.running_jobs);
      const total = parseInt(t.total_jobs);
      const status = running > 0 ? '🟢' : '🔴';
      const flags = [
        t.is_selected ? '⭐' : '',
        t.auto_reply_enabled ? '💬' : '',
        t.bypass_enabled ? '🛡️' : ''
      ].filter(Boolean).join(' ');
      return `${status} **#${t.id} — ${t.token_name}** ${flags}\n` +
             `\`${maskToken(t.token_value)}\` · **${running}/${total}** jobs running`;
    }).join('\n\n');
    embed.addFields({ name: `🔑 Your Tokens (${tokens.length})`, value: tokenList.slice(0, 1024) });
  }

  embed.setFooter({ text: 'AUT0adv • ⭐ Selected  💬 Auto-Reply  🛡️ Bypass' }).setTimestamp();
  return { embed, tokens };
}

function buildDashboardComponents(tokens) {
  const rows = [];

  rows.push(new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('dash_startall').setLabel('▶ Start All').setStyle(ButtonStyle.Success),
    new ButtonBuilder().setCustomId('dash_stopall').setLabel('⏹ Stop All').setStyle(ButtonStyle.Danger),
    new ButtonBuilder().setCustomId('dash_addtoken').setLabel('➕ Add Token').setStyle(ButtonStyle.Primary),
    new ButtonBuilder().setCustomId('dash_refresh').setLabel('🔄 Refresh').setStyle(ButtonStyle.Secondary)
  ));

  if (tokens.length > 0) {
    rows.push(new ActionRowBuilder().addComponents(
      new StringSelectMenuBuilder()
        .setCustomId('dash_select_token')
        .setPlaceholder('⚙️ Pick a token to manage...')
        .addOptions(tokens.slice(0, 25).map(t => ({
          label: `#${t.id} — ${t.token_name}`.slice(0, 100),
          description: `${maskToken(t.token_value)} · ${t.running_jobs} running`.slice(0, 100),
          value: String(t.id),
          emoji: parseInt(t.running_jobs) > 0 ? '🟢' : '🔴'
        })))
    ));
  }

  return rows;
}

async function sendDashboard(interaction, discordId, user) {
  const { embed, tokens } = await buildDashboardEmbed(discordId, user);
  return interaction.editReply({ embeds: [embed], components: buildDashboardComponents(tokens) });
}

// ─── TOKEN DETAIL ─────────────────────────────────────────────────────────────

async function sendTokenDetail(interaction, discordId, tokenId) {
  const res = await query(
    `SELECT t.*,
      (SELECT COUNT(*) FROM ad_jobs aj WHERE aj.token_id = t.id AND aj.is_running = TRUE) as running_jobs,
      (SELECT COUNT(*) FROM ad_jobs aj WHERE aj.token_id = t.id) as total_jobs
     FROM tokens t WHERE t.id = $1 AND t.user_discord_id = $2`,
    [tokenId, discordId]
  );
  const t = res.rows[0];
  if (!t) return;

  const jobsRes = await query(`SELECT * FROM ad_jobs WHERE token_id = $1 ORDER BY id`, [tokenId]);
  const jobs = jobsRes.rows;

  const jobList = jobs.length
    ? jobs.map(j => {
        const channels = j.channel_ids || [];
        const images = j.images || [];
        const msg = j.message.length > 55 ? j.message.slice(0, 55) + '…' : j.message;
        return `${isJobRunning(j.id) ? '🟢' : '🔴'} **Job #${j.id}** · ${channels.length} ch · ${j.delay_seconds}s · ${images.length > 0 ? `🖼️ ${images.length}` : 'no img'}\n> ${msg}`;
      }).join('\n\n')
    : '> No ad jobs yet. Click **➕ New Ad Job** to create one.';

  const embed = new EmbedBuilder()
    .setColor(parseInt(t.running_jobs) > 0 ? 0x57F287 : 0x5865F2)
    .setTitle(`⚙️ Token #${t.id} — ${t.token_name}`)
    .addFields(
      { name: '🔑 Token', value: `\`${maskToken(t.token_value)}\``, inline: true },
      { name: '⭐ Active', value: t.is_selected ? 'Yes' : 'No', inline: true },
      { name: '🟢 Running', value: `${t.running_jobs} / ${t.total_jobs} jobs`, inline: true },
      { name: '💬 Auto-Reply', value: t.auto_reply_enabled ? '✅ On' : '❌ Off', inline: true },
      { name: '🛡️ Bypass', value: t.bypass_enabled ? '✅ On' : '❌ Off', inline: true },
      { name: '\u200B', value: '\u200B', inline: true },
      { name: `📋 Ad Jobs (${jobs.length})`, value: jobList.slice(0, 1024) }
    )
    .setFooter({ text: 'AUT0adv • Token Detail' })
    .setTimestamp();

  const rows = [];

  // Row 1: job actions
  rows.push(new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId(`dash_tok_start_${tokenId}`).setLabel('▶ Start All Jobs').setStyle(ButtonStyle.Success),
    new ButtonBuilder().setCustomId(`dash_tok_stop_${tokenId}`).setLabel('⏹ Stop All Jobs').setStyle(ButtonStyle.Danger),
    new ButtonBuilder().setCustomId(`dash_tok_newjob_${tokenId}`).setLabel('➕ New Ad Job').setStyle(ButtonStyle.Primary),
    new ButtonBuilder().setCustomId('dash_back').setLabel('← Back').setStyle(ButtonStyle.Secondary)
  ));

  // Row 2: token settings
  rows.push(new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId(`dash_tok_reply_${tokenId}`)
      .setLabel(t.auto_reply_enabled ? '🔕 Disable Reply' : '🔔 Enable Reply')
      .setStyle(t.auto_reply_enabled ? ButtonStyle.Secondary : ButtonStyle.Primary),
    new ButtonBuilder()
      .setCustomId(`dash_tok_bypass_${tokenId}`)
      .setLabel(t.bypass_enabled ? '🛡️ Disable Bypass' : '🛡️ Enable Bypass')
      .setStyle(t.bypass_enabled ? ButtonStyle.Secondary : ButtonStyle.Primary),
    new ButtonBuilder()
      .setCustomId(`dash_tok_select_${tokenId}`)
      .setLabel('⭐ Set as Active')
      .setStyle(t.is_selected ? ButtonStyle.Secondary : ButtonStyle.Success)
      .setDisabled(!!t.is_selected),
    new ButtonBuilder()
      .setCustomId(`dash_tok_rename_${tokenId}`)
      .setLabel('✏️ Rename')
      .setStyle(ButtonStyle.Secondary),
    new ButtonBuilder()
      .setCustomId(`dash_tok_remove_${tokenId}`)
      .setLabel('🗑️ Delete Token')
      .setStyle(ButtonStyle.Danger)
  ));

  // Row 3: job selector (if jobs exist)
  if (jobs.length > 0) {
    rows.push(new ActionRowBuilder().addComponents(
      new StringSelectMenuBuilder()
        .setCustomId(`dash_select_job_${tokenId}`)
        .setPlaceholder('📋 Select a job to view or edit...')
        .addOptions(jobs.slice(0, 25).map(j => {
          const channels = j.channel_ids || [];
          const msg = j.message.length > 50 ? j.message.slice(0, 50) + '…' : j.message;
          return {
            label: `Job #${j.id} — ${channels.length} ch · ${j.delay_seconds}s`.slice(0, 100),
            description: msg.slice(0, 100),
            value: String(j.id),
            emoji: isJobRunning(j.id) ? '🟢' : '🔴'
          };
        }))
    ));
  }

  return interaction.editReply({ embeds: [embed], components: rows });
}

// ─── JOB DETAIL ──────────────────────────────────────────────────────────────

async function sendJobDetail(interaction, discordId, jobId, tokenId) {
  const jobRes = await query(`SELECT * FROM ad_jobs WHERE id = $1 AND user_discord_id = $2`, [jobId, discordId]);
  const j = jobRes.rows[0];
  if (!j) return;

  const channels = j.channel_ids || [];
  const images = j.images || [];
  const running = isJobRunning(jobId);

  const embed = new EmbedBuilder()
    .setColor(running ? 0x57F287 : 0xED4245)
    .setTitle(`📋 Ad Job #${j.id} — ${running ? '🟢 Running' : '🔴 Stopped'}`)
    .addFields(
      {
        name: '💬 Message',
        value: j.message.length > 500 ? j.message.slice(0, 500) + '…' : j.message
      },
      {
        name: '📡 Channels',
        value: channels.length > 0
          ? channels.map(c => `<#${c}>`).join(' ')
          : 'None set',
        inline: true
      },
      { name: '⏱️ Delay', value: `${j.delay_seconds}s per cycle`, inline: true },
      { name: '🖼️ Images', value: images.length > 0 ? `${images.length} attached` : 'None', inline: true },
      {
        name: '🔄 Last Cycle',
        value: j.last_cycle_at
          ? `<t:${Math.floor(new Date(j.last_cycle_at).getTime() / 1000)}:R>`
          : 'Not started yet',
        inline: true
      },
      {
        name: '📅 Created',
        value: `<t:${Math.floor(new Date(j.created_at).getTime() / 1000)}:D>`,
        inline: true
      }
    )
    .setFooter({ text: 'AUT0adv • Job Detail' })
    .setTimestamp();

  const rows = [
    new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId(`dash_job_toggle_${jobId}_${tokenId}`)
        .setLabel(running ? '⏹ Stop Job' : '▶ Start Job')
        .setStyle(running ? ButtonStyle.Danger : ButtonStyle.Success),
      new ButtonBuilder()
        .setCustomId(`dash_job_edit_${jobId}_${tokenId}`)
        .setLabel('✏️ Edit Job')
        .setStyle(ButtonStyle.Primary),
      new ButtonBuilder()
        .setCustomId(`dash_job_delete_${jobId}_${tokenId}`)
        .setLabel('🗑️ Delete Job')
        .setStyle(ButtonStyle.Danger),
      new ButtonBuilder()
        .setCustomId(`dash_tok_back_${tokenId}`)
        .setLabel('← Back')
        .setStyle(ButtonStyle.Secondary)
    )
  ];

  return interaction.editReply({ embeds: [embed], components: rows });
}

// ─── MODALS ──────────────────────────────────────────────────────────────────

function buildAddTokenModal() {
  const modal = new ModalBuilder()
    .setCustomId('dash_modal_addtoken')
    .setTitle('➕ Add a Discord Token');

  modal.addComponents(
    new ActionRowBuilder().addComponents(
      new TextInputBuilder()
        .setCustomId('modal_token_value')
        .setLabel('Discord Account Token')
        .setStyle(TextInputStyle.Short)
        .setPlaceholder('Paste your Discord user token here...')
        .setRequired(true)
        .setMaxLength(100)
    ),
    new ActionRowBuilder().addComponents(
      new TextInputBuilder()
        .setCustomId('modal_token_name')
        .setLabel('Nickname for this token')
        .setStyle(TextInputStyle.Short)
        .setPlaceholder('e.g. Main Account, Alt #2...')
        .setRequired(false)
        .setMaxLength(50)
    )
  );
  return modal;
}

function buildRenameTokenModal(tokenId, currentName) {
  const modal = new ModalBuilder()
    .setCustomId(`dash_modal_renametoken_${tokenId}`)
    .setTitle('✏️ Rename Token');

  modal.addComponents(
    new ActionRowBuilder().addComponents(
      new TextInputBuilder()
        .setCustomId('modal_token_name')
        .setLabel('New name for this token')
        .setStyle(TextInputStyle.Short)
        .setValue(currentName || '')
        .setRequired(true)
        .setMaxLength(50)
    )
  );
  return modal;
}

function buildJobModal(tokenId, jobId, existing) {
  const modal = new ModalBuilder()
    .setCustomId(jobId ? `dash_modal_editjob_${jobId}_${tokenId}` : `dash_modal_newjob_${tokenId}`)
    .setTitle(jobId ? '✏️ Edit Ad Job' : '➕ New Ad Job');

  const messageInput = new TextInputBuilder()
    .setCustomId('modal_message')
    .setLabel('Message to send')
    .setStyle(TextInputStyle.Paragraph)
    .setPlaceholder('The ad message that will be sent to all channels...')
    .setRequired(true)
    .setMaxLength(2000);
  if (existing?.message) messageInput.setValue(existing.message);

  const channelsInput = new TextInputBuilder()
    .setCustomId('modal_channels')
    .setLabel('Channel IDs (space or comma separated)')
    .setStyle(TextInputStyle.Short)
    .setPlaceholder('123456789012345678 987654321098765432')
    .setRequired(true)
    .setMaxLength(1000);
  if (existing?.channel_ids?.length) channelsInput.setValue(existing.channel_ids.join(' '));

  const delayInput = new TextInputBuilder()
    .setCustomId('modal_delay')
    .setLabel('Delay in seconds between full cycles')
    .setStyle(TextInputStyle.Short)
    .setPlaceholder('60')
    .setRequired(false)
    .setMaxLength(6);
  if (existing?.delay_seconds) delayInput.setValue(String(existing.delay_seconds));

  const imagesInput = new TextInputBuilder()
    .setCustomId('modal_images')
    .setLabel('Image URLs (optional, space/comma separated)')
    .setStyle(TextInputStyle.Short)
    .setPlaceholder('https://i.imgur.com/xxx.png')
    .setRequired(false)
    .setMaxLength(2000);
  if (existing?.images?.length) imagesInput.setValue(existing.images.join(' '));

  modal.addComponents(
    new ActionRowBuilder().addComponents(messageInput),
    new ActionRowBuilder().addComponents(channelsInput),
    new ActionRowBuilder().addComponents(delayInput),
    new ActionRowBuilder().addComponents(imagesInput)
  );
  return modal;
}

// ─── INTERACTION HANDLER ─────────────────────────────────────────────────────

export async function handleInteraction(interaction) {
  const discordId = interaction.user.id;
  const userRes = await query(
    `SELECT u.*, lk.expires_at, lk.type FROM users u LEFT JOIN license_keys lk ON lk.id = u.key_id WHERE u.discord_id = $1`,
    [discordId]
  );
  const user = userRes.rows[0];
  if (!user) return;

  // ── Modals ──────────────────────────────────────────────────────────────────
  if (interaction.isModalSubmit()) {
    return handleModal(interaction, discordId, user);
  }

  // ── Select Menus ────────────────────────────────────────────────────────────
  if (interaction.isStringSelectMenu()) {
    await interaction.deferUpdate();
    const id = interaction.customId;

    if (id === 'dash_select_token') {
      return sendTokenDetail(interaction, discordId, parseInt(interaction.values[0]));
    }
    if (id.startsWith('dash_select_job_')) {
      const tokenId = parseInt(id.replace('dash_select_job_', ''));
      return sendJobDetail(interaction, discordId, parseInt(interaction.values[0]), tokenId);
    }
    return;
  }

  if (!interaction.isButton()) return;

  const id = interaction.customId;

  // ── Buttons that show modals (no deferUpdate) ────────────────────────────────
  if (id === 'dash_addtoken') {
    return interaction.showModal(buildAddTokenModal());
  }
  if (id.startsWith('dash_tok_newjob_')) {
    const tokenId = parseInt(id.replace('dash_tok_newjob_', ''));
    return interaction.showModal(buildJobModal(tokenId, null, null));
  }
  if (id.startsWith('dash_tok_rename_')) {
    const tokenId = parseInt(id.replace('dash_tok_rename_', ''));
    const res = await query(`SELECT token_name FROM tokens WHERE id = $1`, [tokenId]);
    return interaction.showModal(buildRenameTokenModal(tokenId, res.rows[0]?.token_name));
  }
  if (id.startsWith('dash_job_edit_')) {
    const parts = id.split('_');
    const jobId = parseInt(parts[3]);
    const tokenId = parseInt(parts[4]);
    const jobRes = await query(`SELECT * FROM ad_jobs WHERE id = $1`, [jobId]);
    return interaction.showModal(buildJobModal(tokenId, jobId, jobRes.rows[0]));
  }

  // ── All other buttons need deferUpdate ──────────────────────────────────────
  await interaction.deferUpdate();

  // Main dashboard navigation
  if (id === 'dash_refresh' || id === 'dash_back') {
    return sendDashboard(interaction, discordId, user);
  }

  // Start/Stop all (global)
  if (id === 'dash_startall') {
    const jobs = await query(`SELECT id FROM ad_jobs WHERE user_discord_id = $1 AND is_running = FALSE`, [discordId]);
    for (const j of jobs.rows) {
      await query(`UPDATE ad_jobs SET is_running = TRUE WHERE id = $1`, [j.id]);
      await startAdJob(j.id, interaction.client);
    }
    return sendDashboard(interaction, discordId, user);
  }
  if (id === 'dash_stopall') {
    const jobs = await query(`SELECT id FROM ad_jobs WHERE user_discord_id = $1`, [discordId]);
    for (const j of jobs.rows) await stopAdJob(j.id);
    return sendDashboard(interaction, discordId, user);
  }

  // Back to token detail
  if (id.startsWith('dash_tok_back_')) {
    const tokenId = parseInt(id.replace('dash_tok_back_', ''));
    return sendTokenDetail(interaction, discordId, tokenId);
  }

  // Token-level actions: dash_tok_{action}_{tokenId}
  if (id.startsWith('dash_tok_')) {
    const parts = id.split('_');
    // parts: ['dash', 'tok', action, tokenId]
    const action = parts[2];
    const tokenId = parseInt(parts[3]);

    if (action === 'start') {
      const jobs = await query(`SELECT id FROM ad_jobs WHERE token_id = $1 AND is_running = FALSE`, [tokenId]);
      for (const j of jobs.rows) {
        await query(`UPDATE ad_jobs SET is_running = TRUE WHERE id = $1`, [j.id]);
        await startAdJob(j.id, interaction.client);
      }
      return sendTokenDetail(interaction, discordId, tokenId);
    }
    if (action === 'stop') {
      const jobs = await query(`SELECT id FROM ad_jobs WHERE token_id = $1`, [tokenId]);
      for (const j of jobs.rows) await stopAdJob(j.id);
      return sendTokenDetail(interaction, discordId, tokenId);
    }
    if (action === 'reply') {
      const t = await query(`SELECT auto_reply_enabled FROM tokens WHERE id = $1`, [tokenId]);
      await query(`UPDATE tokens SET auto_reply_enabled = $1 WHERE id = $2`, [!t.rows[0].auto_reply_enabled, tokenId]);
      return sendTokenDetail(interaction, discordId, tokenId);
    }
    if (action === 'bypass') {
      const t = await query(`SELECT bypass_enabled FROM tokens WHERE id = $1`, [tokenId]);
      await query(`UPDATE tokens SET bypass_enabled = $1 WHERE id = $2`, [!t.rows[0].bypass_enabled, tokenId]);
      return sendTokenDetail(interaction, discordId, tokenId);
    }
    if (action === 'select') {
      await query(`UPDATE tokens SET is_selected = FALSE WHERE user_discord_id = $1`, [discordId]);
      await query(`UPDATE tokens SET is_selected = TRUE WHERE id = $1`, [tokenId]);
      return sendTokenDetail(interaction, discordId, tokenId);
    }
    if (action === 'remove') {
      const jobs = await query(`SELECT id FROM ad_jobs WHERE token_id = $1`, [tokenId]);
      for (const j of jobs.rows) await stopAdJob(j.id);
      await query(`DELETE FROM tokens WHERE id = $1 AND user_discord_id = $2`, [tokenId, discordId]);
      return sendDashboard(interaction, discordId, user);
    }
  }

  // Job-level actions: dash_job_{action}_{jobId}_{tokenId}
  if (id.startsWith('dash_job_')) {
    const parts = id.split('_');
    const action = parts[2];
    const jobId = parseInt(parts[3]);
    const tokenId = parseInt(parts[4]);

    if (action === 'toggle') {
      if (isJobRunning(jobId)) {
        await stopAdJob(jobId);
      } else {
        await query(`UPDATE ad_jobs SET is_running = TRUE WHERE id = $1`, [jobId]);
        await startAdJob(jobId, interaction.client);
      }
      return sendJobDetail(interaction, discordId, jobId, tokenId);
    }
    if (action === 'delete') {
      await stopAdJob(jobId);
      await query(`DELETE FROM ad_jobs WHERE id = $1 AND user_discord_id = $2`, [jobId, discordId]);
      return sendTokenDetail(interaction, discordId, tokenId);
    }
  }
}

// ─── MODAL HANDLER ────────────────────────────────────────────────────────────

async function handleModal(interaction, discordId, user) {
  await interaction.deferUpdate();
  const id = interaction.customId;

  // ── Add Token ─────────────────────────────────────────────────────────────
  if (id === 'dash_modal_addtoken') {
    const tokenValue = interaction.fields.getTextInputValue('modal_token_value').trim();
    const tokenName = interaction.fields.getTextInputValue('modal_token_name').trim() || `Token ${Date.now()}`;

    const existing = await query(
      `SELECT id FROM tokens WHERE user_discord_id = $1 AND token_value = $2`,
      [discordId, tokenValue]
    );
    if (existing.rows[0]) {
      // Token already exists — go straight to it
      return sendTokenDetail(interaction, discordId, existing.rows[0].id);
    }

    const ins = await query(
      `INSERT INTO tokens (user_discord_id, token_value, token_name) VALUES ($1, $2, $3) RETURNING id`,
      [discordId, tokenValue, tokenName]
    );
    // Go straight to the new token's detail page
    return sendTokenDetail(interaction, discordId, ins.rows[0].id);
  }

  // ── Rename Token ──────────────────────────────────────────────────────────
  if (id.startsWith('dash_modal_renametoken_')) {
    const tokenId = parseInt(id.replace('dash_modal_renametoken_', ''));
    const newName = interaction.fields.getTextInputValue('modal_token_name').trim();
    await query(`UPDATE tokens SET token_name = $1 WHERE id = $2 AND user_discord_id = $3`, [newName, tokenId, discordId]);
    return sendTokenDetail(interaction, discordId, tokenId);
  }

  // ── New Ad Job ────────────────────────────────────────────────────────────
  if (id.startsWith('dash_modal_newjob_')) {
    const tokenId = parseInt(id.replace('dash_modal_newjob_', ''));
    const { message, channelIds, delay, images } = parseJobModal(interaction);

    if (!channelIds.length) {
      // Re-show main dashboard with a soft error — can't show ephemeral follow-up after deferUpdate
      return sendTokenDetail(interaction, discordId, tokenId);
    }

    const tokenRes = await query(`SELECT * FROM tokens WHERE id = $1 AND user_discord_id = $2`, [tokenId, discordId]);
    if (!tokenRes.rows[0]) return;

    const jobRes = await query(
      `INSERT INTO ad_jobs (token_id, user_discord_id, message, channel_ids, delay_seconds, images, is_running)
       VALUES ($1, $2, $3, $4, $5, $6, TRUE) RETURNING id`,
      [tokenId, discordId, message, JSON.stringify(channelIds), delay, JSON.stringify(images)]
    );
    await startAdJob(jobRes.rows[0].id, interaction.client);
    return sendTokenDetail(interaction, discordId, tokenId);
  }

  // ── Edit Ad Job ───────────────────────────────────────────────────────────
  if (id.startsWith('dash_modal_editjob_')) {
    const parts = id.split('_');
    const jobId = parseInt(parts[3]);
    const tokenId = parseInt(parts[4]);
    const { message, channelIds, delay, images } = parseJobModal(interaction);

    const wasRunning = isJobRunning(jobId);
    if (wasRunning) await stopAdJob(jobId);

    await query(
      `UPDATE ad_jobs SET message = $1, channel_ids = $2, delay_seconds = $3, images = $4, is_running = $5 WHERE id = $6 AND user_discord_id = $7`,
      [message, JSON.stringify(channelIds), delay, JSON.stringify(images), wasRunning, jobId, discordId]
    );

    if (wasRunning) await startAdJob(jobId, interaction.client);
    return sendJobDetail(interaction, discordId, jobId, tokenId);
  }
}

// ─── HELPERS ─────────────────────────────────────────────────────────────────

function parseJobModal(interaction) {
  const message = interaction.fields.getTextInputValue('modal_message');
  const channelInput = interaction.fields.getTextInputValue('modal_channels');
  const delayRaw = interaction.fields.getTextInputValue('modal_delay');
  const imagesRaw = interaction.fields.getTextInputValue('modal_images');

  const channelIds = parseChannelIds(channelInput);
  const delay = parseInt(delayRaw) > 0 ? parseInt(delayRaw) : 60;
  const images = imagesRaw
    ? imagesRaw.split(/[\s,]+/).map(u => u.trim()).filter(u => u.startsWith('http'))
    : [];

  return { message, channelIds, delay, images };
}

# AutoAdv Bot

A full-featured Discord advertising automation bot with license key management, token-based ad campaigns, interactive dashboards, and a reseller system.

## Deploy to Railway (24/7)

### Step 1 — Push to GitHub
1. Create a new repository on [github.com](https://github.com/new) (make it **private**)
2. Push the contents of the `discord-bot/` folder:
   ```bash
   cd discord-bot
   git init
   git add .
   git commit -m "Initial commit"
   git remote add origin https://github.com/YOUR_USERNAME/YOUR_REPO.git
   git push -u origin main
   ```

### Step 2 — Create a Railway project
1. Go to [railway.app](https://railway.app) and sign in with GitHub
2. Click **New Project → Deploy from GitHub repo**
3. Select your repository — Railway detects `railway.json` automatically

### Step 3 — Add a PostgreSQL database
1. Inside your Railway project, click **+ New → Database → Add PostgreSQL**
2. Railway automatically adds `DATABASE_URL` to your bot service

### Step 4 — Set environment variables
In Railway → your bot service → **Variables**, add:

| Variable | Value |
|---|---|
| `DISCORD_TOKEN` | Your bot token (Discord Dev Portal → Bot → Token) |
| `DISCORD_CLIENT_ID` | Your app's client ID (Discord Dev Portal → General Information) |
| `OWNER_IDS` | Your Discord user ID — right-click your name → Copy User ID |

### Step 5 — Deploy slash commands (once)
After the bot is running on Railway, go to your service → **Settings → Deploy** and run a one-off command:
```
node src/deploy-commands.js
```
Or run it locally with your `.env` filled in:
```bash
npm run deploy
```

### Step 6 — Get started in Discord
1. Invite the bot to your server with the OAuth2 URL from Discord Dev Portal
2. Use `/admin_genkey` to generate your first license key
3. Use `/redeem_key <key>` to activate your account
4. Use `/ad` with a token, message, and channels to start advertising
5. Use `/dashboard` to manage everything

---

## Local Development

```bash
cp .env.example .env
# Fill in .env with your values
npm install
npm run deploy   # register slash commands once
npm start        # or: npm run dev (auto-restarts on file changes)
```

---

## Environment Variables

| Variable | Required | Description |
|---|---|---|
| `DISCORD_TOKEN` | ✅ | Bot token from Discord Developer Portal |
| `DISCORD_CLIENT_ID` | ✅ | Application ID from Discord Developer Portal |
| `DATABASE_URL` | ✅ | PostgreSQL connection string (auto-set by Railway) |
| `OWNER_IDS` | Optional | Comma-separated Discord IDs with admin access |

---

## Commands

| Command | Description |
|---|---|
| `/redeem_key` | Activate your account with a license key |
| `/help` | Show all commands |
| `/setup` | Quick-start guide and account status |
| `/dashboard` | Interactive token & job management panel |
| `/ad` | All-in-one: launch an ad campaign |
| `/settoken` | Add a token manually |
| `/listtokens` | List all saved tokens |
| `/selecttoken` | Set a token as active |
| `/removetoken` | Delete a token |
| `/tokenstart` | Start all jobs for a token |
| `/tokenstop` | Stop all jobs for a token |
| `/tokenstatus` | View token and job status |
| `/tokenconfig` | Configure token settings |
| `/configpanel` | Full config panel with buttons |
| `/togglepanel` | Toggle auto-reply & bypass per token |
| `/status` | Full account status |
| `/profile` | Your user profile |
| `/stats` | Ad campaign statistics |
| `/leaderboard` | Top users by active jobs |
| `/startall` | Start all stopped jobs at once |
| `/balance` | Check reseller credit balance |
| `/reseller_gen` | Generate a key using reseller credits |
| `/transfer_reseller` | Transfer credits to another reseller |
| `[Admin] /admin_genkey` | Generate license keys |
| `[Admin] /admin_reseller` | Manage reseller accounts |
| `[Admin] /trial_drop` | Drop free trial keys in a channel |

## License Key Types

| Type | Duration |
|---|---|
| Trial | 3 days |
| Basic | 30 days |
| Premium | 90 days |

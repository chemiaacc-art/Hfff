-- AutoAdv Bot Database Schema
-- Run this on your Railway PostgreSQL database to set up all tables.
-- You can run it with: psql $DATABASE_URL -f schema.sql

CREATE TABLE IF NOT EXISTS users (
  id SERIAL PRIMARY KEY,
  discord_id TEXT UNIQUE NOT NULL,
  username TEXT,
  key_id INTEGER,
  is_reseller BOOLEAN DEFAULT FALSE,
  reseller_balance INTEGER DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS license_keys (
  id SERIAL PRIMARY KEY,
  key_value TEXT UNIQUE NOT NULL,
  type TEXT NOT NULL DEFAULT 'basic',
  duration_days INTEGER NOT NULL DEFAULT 30,
  is_active BOOLEAN DEFAULT TRUE,
  used_by TEXT,
  used_at TIMESTAMPTZ,
  expires_at TIMESTAMPTZ,
  created_by TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS tokens (
  id SERIAL PRIMARY KEY,
  user_discord_id TEXT NOT NULL REFERENCES users(discord_id) ON DELETE CASCADE,
  token_value TEXT NOT NULL,
  token_name TEXT DEFAULT 'My Token',
  is_selected BOOLEAN DEFAULT FALSE,
  auto_reply_enabled BOOLEAN DEFAULT FALSE,
  bypass_enabled BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS ad_jobs (
  id SERIAL PRIMARY KEY,
  token_id INTEGER NOT NULL REFERENCES tokens(id) ON DELETE CASCADE,
  user_discord_id TEXT NOT NULL,
  message TEXT NOT NULL,
  channel_ids JSONB DEFAULT '[]',
  delay_seconds INTEGER DEFAULT 60,
  images JSONB DEFAULT '[]',
  is_running BOOLEAN DEFAULT FALSE,
  last_cycle_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Add foreign key from users to license_keys if not already set
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.table_constraints
    WHERE constraint_name = 'users_key_id_fkey'
  ) THEN
    ALTER TABLE users ADD CONSTRAINT users_key_id_fkey
      FOREIGN KEY (key_id) REFERENCES license_keys(id) ON DELETE SET NULL;
  END IF;
END$$;

-- Indexes for performance
CREATE INDEX IF NOT EXISTS idx_tokens_user ON tokens(user_discord_id);
CREATE INDEX IF NOT EXISTS idx_ad_jobs_token ON ad_jobs(token_id);
CREATE INDEX IF NOT EXISTS idx_ad_jobs_user ON ad_jobs(user_discord_id);
CREATE INDEX IF NOT EXISTS idx_ad_jobs_running ON ad_jobs(is_running) WHERE is_running = TRUE;
CREATE INDEX IF NOT EXISTS idx_license_keys_value ON license_keys(key_value);
